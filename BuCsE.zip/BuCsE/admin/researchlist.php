<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<div class="grid_10">
    <div class="box round first grid">
        <h2>Ongoing Research:</h2>
        <?php
				if(isset($_GET['delid'])){
					$delid=$_GET['delid'];
					$query= "delete from tbl_research where id='$delid'";
					$deldata=$db->delete($query);
					if($deldata){
						echo "<span class='success'> Research deleted Sucessfully</span>";
					}
					else{
						echo "<span class='error'>Research Not deleted.</span>";
					}
					}?>
        <?php
if(isset($_GET['seenid'])){
    $seenid=$_GET['seenid'];
    $query=" Update tbl_research
            SET 
            status='1'
            where id='$seenid'";
			$updated=$db->update($query);
            if($updated){
                echo "<span class='success'> Succesfully sent in Completed Research.</span>";
            }
            else{
                echo "<span class='error'> Something went wrong</span>";
            }
           
  }  ?>
  <?php
  if(isset($_GET['unseenid'])){
    $unseenid=$_GET['unseenid'];
    $query=" Update tbl_research
            SET 
            status='0'
            where id='$unseenid'";
			$updated=$db->update($query);
            if($updated){
                echo "<span class='success'> Succesfully sent in Ongoing Research.</span>";
            }
            else{
                echo "<span class='error'> Something went wrong</span>";
            }
           
  }  ?>


        <div class="block">
            <table class="data display datatable" id="example">
                <thead>
                    <tr>
                        <th width="10%">Serial No.</th>
                        <th width="70%">Research</th>
                        <th width="20%">
                           Action
                        </th>
                    </tr>
                </thead>
                <tbody>
                <?php
					$query="select * from tbl_research where status ='0' order by id desc";
					$msg= $db->select($query);
					if($msg){
						$i=0;
						while($result=$msg->fetch_assoc())
						{
							$i++;
						
					
						?>
                    <tr class="odd gradeX">
                        <td><?php echo $i;?></td>
                        <td><?php echo $result['body'];?></td>
                        <td>
                            <a onclick ="return confirm('Are you sure this research is completed?');" href="?seenid=<?php echo $result['id'];?>">Completed</a> || <a href="editresearch.php?postid=<?php echo $result['id'];?> ">Edit</a> ||  <a onclick ="return confirm('Are you sure to delete this research?');" href="?delid=<?php echo $result['id'];?>">Delete</a> 
                        </td>
                    </tr>
                  <?php
                  
                        }}
                  ?>

                </tbody>
            </table>
        </div>
    </div>
    <div class="box round first grid">
        <h2>Completed Research:</h2>
        <div class="block">
        <table class="data display datatable" id="example">
                <thead>
                    <tr>
                    <th width="10%">Serial No.</th>
                        <th width="70%">Research</th>
                        <th width="20%">
                           Action
                        </th>
                    </tr>
                </thead>
                <tbody>
                <?php
					$query="select * from tbl_research where status ='1' order by id desc";
					$msg= $db->select($query);
					if($msg){
						$i=0;
						while($result=$msg->fetch_assoc())
						{
							$i++;
						
					
						?>
                    <tr class="odd gradeX">
                        <td><?php echo $i;?></td>
                        <td><?php echo $result['body'];?></td>
                        <td> <a onclick ="return confirm('Are you sure this research is Ongoing?');" href="?unseenid=<?php echo $result['id'];?>">Ongoing</a>
                            
                           
                        </td>
                    </tr>
                  <?php
                  
                        }}
                  ?>

                </tbody>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">

        $(document).ready(function () {
            setupLeftMenu();

            $('.datatable').dataTable();
			setSidebarHeight();


        });
    </script>
<?php include 'inc/footer.php'; ?>