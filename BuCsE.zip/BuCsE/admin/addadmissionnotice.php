﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Add New Notice</h2>
               <div class="block copyblock"> 
               <?php
    if($_SERVER['REQUEST_METHOD'] == "POST"){
            
                   
        $title=mysqli_real_escape_string($db->link, $_POST['title']);
          $file_name = $_FILES['pdf']['name'];
          $file_tmp = $_FILES['pdf']['tmp_name'];
          $pdf="pdf/".$file_name;

        if($title==""  || $file_name==""){

            echo "<span class='error'>  Empty filled doesnot allowed</span>";
          }
 else{
          move_uploaded_file($file_tmp, $pdf);
 
          
			$query="insert into  tbl_notice(title,pdf) values('$title','$pdf') ";
			$insert=$db->insert($query);
            if($insert){
                echo "<span class='success'> Notice Inserted Sucessfully</span>";
            }
            else{
                echo "<span class='error'>  Not Inserted </span>";
            }
           
  } } ?>
   <form method="post" enctype="multipart/form-data">
	<div class="form-input py-2">
		<div class="form-group">
		<tr>
                            <td>
                                <label>Title</label>
                            </td>
                            <td class=" m-4 ">
                                <input type="text" class=" pd-4 " name="title" placeholder="Enter  Title" class="medium" />
                            </td>
                        </tr></div>								
		<div class="form-group">
        <tr>
                            <td class=" m-4 ">
                                <label>Upload PDF</label>
                            </td>
                            <td class=" m-4 ">
		<input type="file" name="pdf"
				class=" pd-4 form-control" accept=".pdf"
				title="Upload PDF"/>
                
                            </td>
                        </tr>
                    </div>	
		<div class="pd-4 form-group">
		<input type="submit" class="btnRegister"
				name="submit" value="Submit">
		</div>
    </div>
  </form>

                </div>
            </div>
        </div>
        <?php include 'inc/footer.php'; ?>