<?php  include "../lib/session.php"; 
Session:: checkSession();?>
<?php  
include '../config/config.php';  
include '../lib/Database.php';
include '../helpers/format.php';
$db=new database() ;

?>
 <?php
if(!isset($_GET['id'])|| $_GET['id']==null){
    header("location:postlist.php");
}
else{
    $id=$_GET['id'];
    
    $query="select *   from achieve where id ='$id'";
    $getpost=$db->select($query);
    if($getpost){
        while($del=$getpost->fetch_assoc()){
            $dellink=$del['pdf'];
            unlink($dellink);
        }
    }
    $delquery="delete from tbl_notice where id= '$id'";
    $delpost= $db->delete($delquery);
    if($delpost){
        echo "<script>alert('Data deleted successfully.') </script>";
        header("location:noticelist.php");
    }
    else{
        echo "<script>alert('Data  not deleted .') </script>";
        header("location:noticelist.php");
    }
    }

?>