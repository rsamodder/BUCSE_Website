﻿<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Social Media</h2>
                <?php
                if($_SERVER['REQUEST_METHOD'] == "POST"){
            
                  $Fb=$fm-> validation($_POST['Fb']);
                  $Ln=$fm-> validation($_POST['Ln']); 
                  $Tw=$fm-> validation($_POST['Tw']); 
                  $Gg=$fm-> validation($_POST['Gg']);
                 
               $Fb=mysqli_real_escape_string($db->link, $_POST['Fb']);
               $Ln=mysqli_real_escape_string($db->link, $_POST['Ln']);
               $Tw=mysqli_real_escape_string($db->link, $_POST['Tw']);
               $Gg=mysqli_real_escape_string($db->link, $_POST['Gg']);
               if($Fb==""|| $Ln==""|| $Tw==""|| $Gg=="" ){

                echo "<span class='error'>  Empty filled doesnot allowed</span>";
            }else{

                $query=" Update tbl_social
            SET 
           Fb='$Fb',
           Ln='$Ln',
           Tw='$Tw',
           Gg='$Gg'
           where id='1'";
             
               $updated_rows = $db->update($query);
               if ($updated_rows) {
                echo "<span class='success'>Data updated Successfully.
                </span>";
               }else {
                echo "<span class='error'>Data Not Updated Yet !</span>";
               }
            }
                }?>
                <div class="block">   
                <?php
                    $query="select * from tbl_social where id='1'";
                    $social=$db->select($query);
                    if( $social){
                        while($result= $social->fetch_assoc()){
                    ?>             
                 <form action="" method='post'>
                    <table class="form">					
                        <tr>
                            <td>
                                <label>Facebook</label>
                            </td>
                            <td>
                                <input type="text" name="Fb" value="<?php echo $result['Fb'];?>"  class="medium" />
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label>LinkedIn</label>
                            </td>
                            <td>
                                <input type="text" name="Ln" value="<?php echo $result['Ln'];?>"  class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td>
                                <label>Twitter</label>
                            </td>
                            <td>
                                <input type="text" name="Tw" value="<?php echo $result['Tw'];?>"  class="medium" />
                            </td>
                        </tr>
						
						
						 <tr>
                            <td>
                                <label>Google Plus</label>
                            </td>
                            <td>
                                <input type="text" name="Gg" value="<?php echo $result['Gg'];?>"  class="medium" />
                            </td>
                        </tr>
						
						 <tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Update" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php
                    }}?>
                </div>
            </div>
        </div>
        <div class="clear">
        </div>
    </div>
    <?php include 'inc/footer.php'; ?>