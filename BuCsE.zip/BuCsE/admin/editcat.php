<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
<?php
if(!isset($_GET['catid'])|| $_GET['catid']==null){
    header("location:catlist.php");
}
else{
    $id=$_GET['catid'];
}
?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Category</h2>
               <div class="block copyblock"> 
            <?php  
            if($_SERVER['REQUEST_METHOD'] == "POST"){
            
                 $name=$_POST['name'];
			$name=mysqli_real_escape_string($db->link, $name);
			
            if(empty($name)){
                echo "<span class='error'> Empty Feild not allowed</span>";
            }
            else{
			$query=" Update tbl_cate
            SET 
            name='$name'
            where id='$id'";
			$updated=$db->update($query);
            if($updated){
                echo "<span class='success'> Category updated Sucessfully</span>";
            }
            else{
                echo "<span class='error'>  Not updated Yet</span>";
            }
           
  } } ?>
  <?php
  $query="select * from tbl_cate where id='$id' order by id desc";
$category=  $db->select($query);
while($result=$category->fetch_assoc()){
  ?>
                 <form action="" method="POST">
                    <table class="form">					
                        <tr>
                            <td>
                                <input type="text" value="<?php echo $result['name'];?> " placeholder="Enter Category Name..." name="name" class="medium" />
                            </td>
                        </tr>
						<tr> 
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php
                    }?>
                </div>
            </div>
        </div>
        <?php include 'inc/footer.php'; ?>