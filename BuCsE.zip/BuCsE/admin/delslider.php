<?php  include "../lib/session.php"; 
Session:: checkSession();?>
<?php  
include '../config/config.php';  
include '../lib/Database.php';
include '../helpers/format.php';
$db=new database() ;

?>
 <?php
if(!isset($_GET['delid'])|| $_GET['delid']==null){
    header("location:slidertlist.php");
}
else{
    $id=$_GET['delid'];
    
    $query="select *   from tbl_slider where id ='$id' ";
    $delete=$db->select($query);
    if($delete){
        while($delimg=$delete->fetch_assoc()){
            $dellink=$delimg['image'];
            unlink($dellink);
        }
    }
    $delquery="delete from tbl_slider where id= '$id' ";
    $delpost= $db->delete($delquery);
    if($delpost){
        echo "<script>alert('Slider deleted successfully.') </script>";
        header("location:sliderlist.php");
    }
    else{
        echo "<script>alert('Slider  not deleted .') </script>";
        header("location:sliderlist.php");
    }
    }

?>