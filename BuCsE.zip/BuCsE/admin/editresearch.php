<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>
        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Achievement </h2>
                <?php
if(!isset($_GET['postid'])|| $_GET['postid']==null){
    header("location:researchlist.php");
}
else{
    $id=$_GET['postid'];
}
?>
                <?php
                if($_SERVER['REQUEST_METHOD'] == "POST"){
            
                   
              
               
               $body=mysqli_real_escape_string($db->link, $_POST['body']);
              
              
              
              
               if( $body=="" ){

                echo "<span class='error'>  Empty filled doesnot allowed</span>";
            }
            
              

$query=" Update tbl_research
            SET 
            
        
            body='$body'
           
            
            where id='$id'";
               $updated_rows = $db->update($query);
               if ($updated_rows) {
                echo "<span class='success'>Data updated Successfully.
                </span>";
               }else {
                echo "<span class='error'>Data Not Updated Yet !</span>";
               }
               }
             
                

                ?>
                <div class="block">      
                    <?php
$query="select * from tbl_research where id='$id'";
$getpost=$db->select($query);
while($postresult=$getpost->fetch_assoc()){

                    ?>         
                 <form action="" method="POST" >
                    <table class="form">
                       
                        
                       
                        <tr>
                            <td style="vertical-align: top; padding-top: 9px;">
                                <label>Content</label>
                            </td>
                            <td>
                                <textarea class="tinymce" name="body" ><?php echo $postresult['body'];?></textarea>
                            </td>
                        </tr>
                        
                       
						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" Value="Save" />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php
                    }?>
                </div>
            </div>
        </div>
       
 <!-- Load TinyMCE -->
 <script src="js/tiny-mce/jquery.tinymce.js" type="text/javascript"></script>
    <script type="text/javascript">
        $(document).ready(function () {
            setupTinyMCE();
            setDatePicker('date-picker');
            $('input[type="checkbox"]').fancybutton();
            $('input[type="radio"]').fancybutton();
        });
    </script>
		<script type="text/javascript">
        $(document).ready(function () {
            setupLeftMenu();
		    setSidebarHeight();
        });
    </script>
    <!-- /TinyMCE -->
    <?php include 'inc/footer.php'; ?>
