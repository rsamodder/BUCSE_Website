-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2022 at 06:10 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bu_cse`
--

-- --------------------------------------------------------

--
-- Table structure for table `faculty`
--

CREATE TABLE `faculty` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `gmail` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty`
--

INSERT INTO `faculty` (`id`, `name`, `position`, `gmail`, `phone`, `img`) VALUES
(1, 'Md Irfan', 'Assistant Professor & Chairman', 'irfan.bucse@gmail.com', 'Cell :01799598455.', 'image/erfansir.jpg'),
(2, 'Dr. Md Manjur Ahmed', 'Assistant Professor', 'manjur_39@yahoo.com', '01851924944', 'image/monjursir.jpg'),
(3, 'Rahat Hossain Faisal', 'Assistant Professor', 'rhfaisal@gmail.com;', '8801733977761', 'image/rahatsir.jpg'),
(4, 'Md. Samsuddoha', 'Assistant Professor', 'sams.csebu@gmail.com', '01737349075', 'image/shamssir.jpg'),
(5, 'Md. Rashid Al Asif', 'Lecturer', 'rashid.al.asif@gmail.com', 'Cell :01734528367', 'image/rashidsir.jpg'),
(6, 'Md. Mustafijur Rahman', 'Assistant Professor', 'mostafij.csebu@gmail.com', '+8801739097182', 'image/mostafijsir.png'),
(7, 'Md Mahbub E Noor', 'Lecturer', 'mahbub0601001@gmail.com', '+8801734094560', 'image/mahboobsir.jpg'),
(8, 'Tania Islam', ' Lecturer', 'tania.bd.09@gmail.com', '01059505136', 'image/taniamadam.png'),
(9, 'Sohely Jahan', ' Lecturer', 'sohely.cse@gmail.com', '01317419066', 'image/sohelymadam.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `id` int(11) NOT NULL,
  `session` int(11) NOT NULL,
  `course` int(11) NOT NULL,
  `materials` varchar(255) NOT NULL,
  `semester` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`id`, `session`, `course`, `materials`, `semester`) VALUES
(1, 2, 34, 'result.pdf', 5);

-- --------------------------------------------------------

--
-- Table structure for table `semester`
--

CREATE TABLE `semester` (
  `id` int(11) NOT NULL,
  `semester` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semester`
--

INSERT INTO `semester` (`id`, `semester`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6),
(7, 7),
(8, 8);

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE `session` (
  `id` int(11) NOT NULL,
  `session` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`id`, `session`) VALUES
(1, '2017-18'),
(2, '2018-19'),
(3, '2019-20'),
(4, '2020-21'),
(5, '2021-22');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `roll` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `reg.` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `session_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `name`, `email`, `roll`, `details`, `reg.`, `photo`, `phone`, `session_id`, `semester_id`) VALUES
(2, 'Sadia Jahan Rima', 'sadiya.cse6.bu@gmail.com', '19CSE007', 'student', '110-007-19', 'rima.jpg', '01710...', 2, 5),
(3, 'Hafsa Akter', 'hafsa@gmail.com', '18CSE008', 'student', '110-008-18', 'cse.jpeg', '019..', 1, 7);

-- --------------------------------------------------------

--
-- Table structure for table `stuffs`
--

CREATE TABLE `stuffs` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stuffs`
--

INSERT INTO `stuffs` (`id`, `name`, `position`, `phone`, `email`, `img`) VALUES
(1, 'Farjana Yesmin', 'Administrative Officer', 'Cell :01799598455.', 'yesminfarajana61@gmail.com', 'image/yeasmin.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cate`
--

CREATE TABLE `tbl_cate` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cate`
--

INSERT INTO `tbl_cate` (`id`, `name`) VALUES
(1, 'BU'),
(2, 'SBMC'),
(3, 'BMC'),
(4, 'BCC'),
(8, 'SARSTEC'),
(9, 'UGV');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `firstname`, `lastname`, `email`, `body`, `date`, `status`) VALUES
(11, 'S', 'Ema', 'sefatanema@gmail.com', 'Hellow', '2022-10-30 10:34:24', 1),
(12, 'S', 'Ema', 's@gmail.com', 'Need Help!', '2022-10-30 10:34:15', 1),
(13, 'Sefatan', 'Ema', 'sefatanema@gmail.com', 'Hellow', '2022-10-30 10:33:53', 0),
(14, 'S', 'Ema', 'ema.cse6.bu@gmail.com', 'Hellow! This is Ema', '2022-10-30 10:33:20', 0),
(15, 'Sefatan', 'Ema', 'ema.cse6.bu@gmail.com', 'hi!', '2022-10-30 10:33:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cpy`
--

CREATE TABLE `tbl_cpy` (
  `id` int(11) NOT NULL,
  `note` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cpy`
--

INSERT INTO `tbl_cpy` (`id`, `note`) VALUES
(1, '© 2022 Department of Computer Science and Engineering, University of Barishal.');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--

CREATE TABLE `tbl_page` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `body` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `name`, `body`) VALUES
(1, 'About  ', '<p>Hi, this is Sefatan Sowda Ema.&nbsp;My home district is Barisal.&nbsp;I am a university 3rd year student&nbsp; and currently doing my BSc. bearing&nbsp;student ID 19CSE009 in Computer Science And Engineering&nbsp;at university of barishal. My admi'),
(4, 'Sefatan Ema', '<p>Hi, this is Sefatan Sowda Ema.&nbsp;My home district is Barisal.&nbsp;I am a university 3rd year student&nbsp; and currently doing my BSc. bearing&nbsp;student ID 19CSE009 in Computer Science And Engineering&nbsp;at university of barishal. My admi');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `categ` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(266) NOT NULL,
  `author` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `categ`, `title`, `body`, `image`, `author`, `tags`, `date`, `userId`) VALUES
(5, 2, 'Sher-e-Bangla Medical College', '<p>Sher-e-Bangla Medical College&nbsp;(SBMC) is a&nbsp;government&nbsp;medical school&nbsp;in&nbsp;Bangladesh, established in 1968. The college is located in&nbsp;Barisal. It is affiliated with&nbsp;University of Dhaka&nbsp;as a constituent college.</p>\r\n<p>SBMC awards MBBS degree and offers professional training and medical research facility at its hospital with 1000 beds. As per the declaration of overseas registration of the General Medical Council, the awarded MBBS degree during or after October 1984 is eligible to apply for registration in United Kingdom. The college has an area of about 81.545 acres. Student dormitories, nursing institute, nurses\' training institute, dormitory for staff nurses, and residences of teachers are situated on the campus. Construction began on the college on 6 November 1964, at which time it was known as Barisal Medical College. It opened to students in 1968 and was soon renamed to its current title, bestowed in honor of former prime minister&nbsp;A. K. Fazlul Huq&nbsp;in 1977,&nbsp;a resident of Barisal, was often called by the phrase \"Sher-e-Bangla\", which translates \"The Tiger of Bengal</p>\r\n<p>The campus is spacious with College building containing 4 Air conditioned multimedia lecture galleries, an enriched library, students reading room, doctor\'s reading room, cyber cafe. The campus house 1000 bed hospital with a 30-bed burn and plastic surgery unit, a 10-bed ICU unit, a new COVID unit with 150 beds and 18 ICU, DOTS corner, 15 bed CCU, One stop Crisis Center, RH Step, Institute of Nuclear Medicine And Allied Sciences. It also has a Shaheed Minar, Mukta Mancha and Golden Jubilee Memoir.</p>', 'upload/5d7ba03b6e.jpg', 'Ema', 'SBMC', '2022-10-31 16:55:21', 0),
(6, 1, 'University Of Barishal', '<p>University of Barishal is a public university located in Barishal, a divisional city in southern Bangladesh. It is the only general public university in Barishal division and the country\'s 33rd public university. The university was established in 2011 and began academic activities on 24 January 2012.</p>\r\n<p>Demand for a university in the area was first made in 1960 before the&nbsp;independence of Bangladesh. In 1973, then-Prime Minister&nbsp;Sheikh Mujibur Rahman&nbsp;declared he wished to establish a university in&nbsp;Barishal&nbsp;during a rally held in the city. President&nbsp;Ziaur Rahman&nbsp;made a similar statement concerning establishing a university in Barishal on 23 November 1978, at a rally in Barishal Circuit House. In 1990s, former president&nbsp;Abdur Rahman Biswas&nbsp;also made a statement for the establishment of the university.</p>\r\n<p>After three decades, following strong demand from the people of Barisal, the proposal was passed in&nbsp;ECNEC&nbsp;on 20 November 2008, by then&nbsp;Caretaker Government. The law of the University of Barishal has been amended and passed by the National Assembly of Bangladesh on 16 June 2010. On 22 February 2011, Prime Minister&nbsp;Sheikh Hasina&nbsp;inaugurated the construction of a building of the university. The university officially started functioning from the first day of July 2011 in a temporary campus at&nbsp;Barisal Zilla School. Educational activities were inaugurated by&nbsp;Minister for Education&nbsp;Nurul Islam Nahid&nbsp;on 24 January 2012, in the temporary campus of the university. President&nbsp;Zillur Rahman&nbsp;and Professor Dr. Md. Harunor Rashid Khan, from&nbsp;University of Dhaka&nbsp;adorned the chairs of the Founder Chancellor and Vice-Chancellor respectively.</p>\r\n<p>The construction of the main campus started in 2012 which is located at Karnakathi on the eastern bank of the&nbsp;Kirtankhola&nbsp;river in&nbsp;Barisal Sadar Upazila. Tk. 900&nbsp; million was sanctioned to construct the university on 50 acres of land, including 12 acres of private and 38 acres public land. In academic year 2011&ndash;2012 around 400 students were enrolled in six inaugural departments - English, Management, Marketing, Economics and Mathematics.</p>', 'upload/0a7c4025f2.jpg', '   Sefatan Ema', 'bu', '2022-10-31 16:48:03', 0),
(7, 3, 'Brojomohun College', '<p>Govt. Brojomohun College, Barishal&nbsp;(also&nbsp;BM College) is one of the oldest institutions of higher education in&nbsp;Bangladesh. It is located in the city of&nbsp;Barisal&nbsp;in south-western Bangladesh.</p>\r\n<p>On June 14, 1889,&nbsp;Aswini Kumar Dutta&nbsp;founded Brojo Mohan College, which was named after his father,&nbsp;Brajamohan Dutta.</p>\r\n<p>The first principal of the college was&nbsp;Babu Gyan Chandra Chowdhury. While&nbsp;Ashwini Kumar Dutta&nbsp;taught English and logic, Kali Prasanna Ghosh taught history and&nbsp;Kamini Kumar BidyaRatna&nbsp;taught&nbsp;Sanskrit&nbsp;and&nbsp;Bengali. In 1898, BM College was transformed into a \"First Grade College\" from a \"Second Grade College\". In 1912, the college went to government management from&nbsp;personal management&nbsp;strategy. In the beginning the college used the BM School campus and was relocated its own present complex sometime later.</p>\r\n<p>BM College, affiliated to Calcutta University, started honours course in English and philosophy in 1922, in Sanskrit and mathematics in 1925, in chemistry in 1928, and finally in economics in 1929. The time from 1922 to 1948 is called the \"Golden Period\" of the college. The governor of Bengal at that time, Sir Udbarn, once commented on BM College, \"The college promises some day to challenge the supremacy of the metropolitan (Presidency) College.\"</p>\r\n<p>After the partition of India and Pakistan in 1947, the college lacked teachers and the student body fell to one third of its post-war size. This made it difficult to teach the same numbers of courses and as a result the two year Honors curriculum conducted by Calcutta University was replaced with the three Honors curriculum of Dhaka University. As a consequence, Honors courses except Mathematics were abolished in 1950. In 1952, Honors in mathematics had also been discontinued. In 1964, Honors in economics restarted. Several other Honors and Masters Courses started between 1972 and 2005.</p>\r\n<p>The time since 1965 has been called the \"Age of Enrichment\" of the college. There are 20 degree (pass) courses, 22 Honors courses and 21 Masters courses at BM College. On 10th January 2014, Honors Course in Statistics was launched under the leadership of Prof. Biplab Kumar Bhattacharjee in collaboration with Prof. Nasim Haider. Professor Biplab Kumar Bhattacharjee was the founding head of the Department of Statistics. Its journey started with only 11 students. HSC course was abolished in 1999.</p>', 'upload/d53d0f037d.jpg', '   Sefatan Ema', 'BM', '2022-10-31 17:11:35', 0),
(8, 4, 'Barisal Cadet College', '<p>Barishal Cadet College&nbsp;is a&nbsp;Military school&nbsp;in Rahmatpur,&nbsp;Babuganj,&nbsp;Barisal,&nbsp;Bangladesh. It is located 12 kilometres (7.5&nbsp;mi) from Barisal, beside the Dhaka Barisal highway. Before the independence of Bangladesh, the then Pakistan government established four cadet colleges by following the British public schools\' model. After independence, due to the success of those schools, the Bangladesh Defense Force kept those colleges (which are high schools by American definition) and established eight more cadet colleges (three girls and five boys).</p>\r\n<p>Previously, it was Barisal Residential Model College. In 1981 the Bangladesh government converted it into a cadet college. Its first principal was Mr Md. Mufazzal Husain who was also the project director during initial phase of development. As a cadet college, it has a large number of placements of its alumni in the national armed forces. In addition, it is notable for its results in the national exams at the secondary school and higher secondary level and the placements of its alumni in national universities.</p>\r\n<p>Barishal Cadet College boards approximately 330 boys between the ages of 12 and 18 (roughly 54 in each year for grade-7 ) through a nationwide admission test composed of written, oral and medical examinations.</p>\r\n<p>The school is headed by a Principal, appointed by the Adjutant General\'s Branch of Bangladesh Army. It contains three houses- Shariatullah, Shaheed Suhrawardy and Sher-e-Bangla each headed by a housemaster, selected from the senior members of the teaching staff. Like all other Cadet Colleges it also exerts importance towards the self-development and self dependency of its cadets. Cadets of this college are performing in every aspect of the development of the nation. Every year in academic side, the cadets are showing their brilliance in SSC HSC and also in further education.</p>', 'upload/234abaf170.jpg', ' Ema', 'bcc', '2022-10-31 17:16:20', 0),
(9, 8, 'Shahid Abdur Rab Serniabat Textile Engineering College', '<p>Shahid Abdur Rab Serniabat Textile Engineering College, also known as&nbsp;Sarstec, is a&nbsp;textile engineering&nbsp;college located at&nbsp;Barisal,&nbsp;Bangladesh. It is a constituent college of&nbsp;Bangladesh University of Textiles. The institution was first launched as a textile institute with the name \"Institute of Textiles, Barisal\" in 1980. In 2010, it went through a campus wide renovation and was renamed as a college. Sarstec has housing facility for its regular students. Separate dormitories for male and female students are available in adequate capacity. The boys\' hall accommodates for around 400 students and the girls\' hall houses around 150 students.</p>', 'upload/a35448b3db.jpg', '   Sefatan Ema', 'Sarstec', '2022-10-31 17:23:38', 0),
(10, 9, 'Barishal Zilla School', '<p>Barishal Zilla School&nbsp;popularly known as&nbsp;BZS, is a&nbsp;public&nbsp;educational institution for boys, located in&nbsp;Barisal, Bangladesh. It was the first high school established in&nbsp;Barisal Division.&nbsp;It was founded as&nbsp;Barisal English School&nbsp;on 23 December 1829 by W. N. Garrett. It began with 27 students. In 1853, it was renamed Barisal Zilla School</p>', 'upload/6c1583de79.jpg', '   Ema', 'bzs', '2022-10-31 17:29:47', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `title`, `image`) VALUES
(5, '3rd slide title', 'upload/slider/1f49957daa.jpg'),
(6, '2nd slide title', 'upload/slider/93240b57e1.jpg'),
(8, '4rth slide title', 'upload/slider/21d5e3bad6.jpg'),
(10, '4rth slide title', 'upload/slider/aac51b0ae5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social`
--

CREATE TABLE `tbl_social` (
  `id` int(11) NOT NULL,
  `Fb` varchar(250) NOT NULL,
  `Ln` varchar(250) NOT NULL,
  `Tw` varchar(250) NOT NULL,
  `Gg` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_social`
--

INSERT INTO `tbl_social` (`id`, `Fb`, `Ln`, `Tw`, `Gg`) VALUES
(1, 'www.facebook.com', 'www.lnkedin.com', 'www.twitter.com', 'www.google.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `email`, `details`, `role`) VALUES
(16, 'Sefatan Sowda Ema', '202cb962ac59075b964b07152d234b70', 'ema.cse6.bu@gmail.com', '', 3),
(17, 'Sefatan Ema', '202cb962ac59075b964b07152d234b70', 'sefatanema@gmail.com', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `title_slogan`
--

CREATE TABLE `title_slogan` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `inst` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `title_slogan`
--

INSERT INTO `title_slogan` (`id`, `title`, `inst`, `logo`) VALUES
(1, 'Department of Computer Science and Engineering', 'University Of Barishal', 'image/Barishal_University_logo.svg.png');

-- --------------------------------------------------------

--
-- Table structure for table `undergraduate`
--

CREATE TABLE `undergraduate` (
  `course_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `s_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `undergraduate`
--

INSERT INTO `undergraduate` (`course_id`, `title`, `code`, `credit`, `s_id`) VALUES
(1, 'Introduction to Computer Systems', 'CSE-1101', '3 Credit, 45 Hours', 1),
(2, 'Introduction to Computer Systems Lab', ' CSE-1102', '0.75 Credit, 30 Hours', 1),
(3, ' Programming Fundamentals', 'CSE-1103', '3 Credit, 45 Hours', 1),
(4, 'Programming Fundamentals Lab', 'CSE-1104', '1.5 Credit, 45 Hours', 1),
(5, 'Physics', 'PHY-1105', '3 Credit, 45 Hours', 1),
(6, 'Physics Lab', 'PHY-1106', '1.5 Credit, 45 Hours', 1),
(7, 'Chemistry', 'CHEM-1107', '3 Credit, 45 Hours', 1),
(8, 'Chemistry Lab', 'CHEM-1108', '0.75 Credit, 45 Hours', 1),
(9, 'Differential Calculus and Co-ordinate Geometry', 'MATH-1109', '3 Credit, 45 Hours', 1),
(10, 'English Communication Skills Lab', 'ENG-1110', '1.5 Credit, 45 Hours', 1),
(11, 'Data Structures ', 'CSE-1201', '3 Credit, 45 Hours', 2),
(12, 'Data Structures Lab', 'CSE-1202', '0.75 Credit, 30 Hours', 2),
(13, 'Discrete Mathematics', 'CSE-1203', '3 Credit, 45 Hours', 2),
(14, 'Discrete Mathematics Lab ', 'CSE-1204', '0.75 Credit, 30 Hours', 2),
(15, 'Introduction to Electrical Engineering	  ', 'EEE-1205', '3 Credit, 45 Hours', 2),
(16, 'Introduction to Electrical Engineering Lab ', ' EEE-1206', '1.5 Credit, 45 Hours', 2),
(17, 'Basic Mechanical Engineering  ', 'EEE-1207', '3 Credit, 45 Hours', 2),
(18, 'Engineering Drawing', 'EEE-1208', ' 0.75 Credit, 30 Hours', 2),
(19, '<small>Integral Calculus, Ordinary and Partial Differential Equations, and Series Solutions</small> ', 'MATH-1209', '3 Credit, 45 Hours', 2),
(20, 'Statistics and Probability ', 'STAT-1211', '3 Credit, 45 Hours', 2),
(21, 'Database Management Systems   ', 'CSE-2101', '3 Credit, 45 Hours', 3),
(22, 'Database Management Systems Lab', 'CSE-2102', '1.5 Credit, 45 Hours', 3),
(23, 'Digital Logic Design', 'CSE-2103', '3 Credit, 45 Hours', 3),
(24, 'Digital Logic Design Lab  ', 'CSE-2104', '1.5 Credit, 45 Hours', 3),
(25, 'Electronic Devices and Circuits', 'EEE-2105', ' 3 Credit, 45 Hours', 3),
(26, 'Electronic Devices and Circuits Lab  ', 'EEE-2106', '1.5 Credit, 45 Hours', 3),
(27, 'Object Oriented Programming  ', 'CSE-2107', '3 Credit, 45 Hours', 3),
(28, 'Object Oriented Programming Lab	  ', 'CSE-2108', '1.5 Credit, 45 Hours', 3),
(29, ' Complex Variable and Matrices', 'MATH-2109', '3 Credit, 45 Hours', 3),
(34, 'Microprocessors and Microcontrollers ', 'CSE-3301', '3 Credit, 45 Hours', 5),
(35, 'Assembly Language, Microprocessors, and Microcontrollers Lab ', 'CSE-3302', '1.5 Credit, 45 Hours', 5),
(36, 'Software Engineering and Information System Design', 'CSE-3303', '3 Credit, 45 Hours', 5),
(37, 'Software Engineering and Information System Design Lab', 'CSE-3304', '1.5 Credit, 45 Hours', 5),
(38, 'Computer Networks ', 'CSE-3305', '3 Credit, 45 Hours', 5),
(39, 'Computer Networks Lab', 'CSE-3306', '1.5 Credit, 45 Hours', 5),
(40, 'Numerical Methods', 'CSE-3307', '3 Credit, 45 Hours', 5),
(41, 'Financial and Managerial Accounting 	 ', 'HUM-3109', '2 Credit, 30 Hours', 5),
(42, 'Economics', ' HUM-3209', '2 Credit, 30 Hours', 5),
(43, 'Technical Writing and Presentation ', 'CSE-3114', '1 Credit, 30 Hours', 5),
(44, 'Design and Analysis of Algorithms  ', 'CSE-2201', '3 Credit, 45 Hours', 4),
(45, 'Design and Analysis of Algorithms Lab	 ', 'CSE-2202', '1.5 Credit, 45 Hours', 4),
(46, 'Computer Architecture and Organization	 ', 'CSE-2203', '3 Credit, 45 Hours', 4),
(47, 'Data Communication', 'CSE-2205', '3 Credit, 45 Hours', 4),
(48, 'Operating System', 'CSE-2207', ' 3 Credit, 45 Hours', 4),
(49, 'Operating System Lab', 'CSE-2208', '1.5 Credit, 45 Hours', 4),
(50, 'Web Engineering Lab', ' CSE-2210', ' 3 Credit, 90 Hours', 4),
(51, 'Vectors, Fourier Analysis, and Laplace Transforms', 'MATH-2211', '3 Credit, 45 Hours', 4),
(52, 'Mathematical Analysis for Computer Science		s', 'CSE-3201', '3 Credit, 45 Hour', 6),
(53, 'Theory of Computation', 'CSE-3203', '3 Credit, 45 Hours', 6),
(54, 'Artificial Intelligence	 ', ' CSE-3205', '3 Credit, 45 Hours', 6),
(55, 'Artificial Intelligence Lab', 'CSE-3206', '1.5 Credit, 45 Hours', 6),
(56, 'Peripherals and Interfacing', 'CSE-3207', '3 Credit, 45 Hours', 6),
(57, 'Peripherals and Interfacing Lab	', 'CSE-3208', '1.5 Credit, 45 Hours', 6),
(58, 'Simulation and Modeling	', 'CSE-3209', ' 3 Credit, 45 Hours', 6),
(59, 'Simulation and Modeling Lab', 'CSE-3210', '0.75 Credit, 30 Hours', 6),
(60, 'Mobile Application Development Lab ', 'CSE-3212', ' 1.5 Credit, 30 Hours', 6),
(61, 'Compiler Design and Construction	   ', 'CSE-4103', '3 Credit, 45 Hours', 7),
(62, 'Compiler Design and Construction Lab   ', 'CSE-4104', '0.75 Credit, 22.5 Hours', 7),
(63, 'System Programming  ', ' CSE-4105', '2.0 Credit, 30 Hours', 7),
(65, 'System Programming Lab', 'CSE-4106', ' 1.5 Credit, 45 Hours', 7),
(66, 'Computer Graphics', ' CSE-4109', '3.0 Credit, 45 Hours', 7),
(67, 'Computer Graphics Lab', ' CSE-4110', '0.75 Credit, 22.5 Hours', 7),
(68, 'Professional Ethics and Industrial Management', ' HUM-3211', ' 3.0 Credit, 45 Hours', 7),
(69, ' Digital Image Processing  \r\n 	  ', 'CSE-4201', '3 Credit, 45 Hours', 8),
(70, ' Project and Thesis', 'CSE-4202', '6 Credit,* hours', 8);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `email`, `password`, `role`) VALUES
(1, 'sadiya.cse6.bu@gmail.com', '110-007-19', 0),
(3, 'sams.csebu@gmail.com', '12345', 1),
(4, 'hafsa@gmail.com', '110-008-18', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `faculty`
--
ALTER TABLE `faculty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`id`),
  ADD KEY `session` (`session`),
  ADD KEY `course` (`course`),
  ADD KEY `semester` (`semester`);

--
-- Indexes for table `semester`
--
ALTER TABLE `semester`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `session`
--
ALTER TABLE `session`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`),
  ADD KEY `semester_id` (`semester_id`),
  ADD KEY `session_id` (`session_id`);

--
-- Indexes for table `stuffs`
--
ALTER TABLE `stuffs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cate`
--
ALTER TABLE `tbl_cate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cpy`
--
ALTER TABLE `tbl_cpy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `title_slogan`
--
ALTER TABLE `title_slogan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `undergraduate`
--
ALTER TABLE `undergraduate`
  ADD PRIMARY KEY (`course_id`),
  ADD KEY `s_id` (`s_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculty`
--
ALTER TABLE `faculty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `semester`
--
ALTER TABLE `semester`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `session`
--
ALTER TABLE `session`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stuffs`
--
ALTER TABLE `stuffs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_cate`
--
ALTER TABLE `tbl_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_cpy`
--
ALTER TABLE `tbl_cpy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `title_slogan`
--
ALTER TABLE `title_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `undergraduate`
--
ALTER TABLE `undergraduate`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `result`
--
ALTER TABLE `result`
  ADD CONSTRAINT `result_ibfk_1` FOREIGN KEY (`session`) REFERENCES `session` (`id`),
  ADD CONSTRAINT `result_ibfk_2` FOREIGN KEY (`course`) REFERENCES `undergraduate` (`course_id`),
  ADD CONSTRAINT `result_ibfk_3` FOREIGN KEY (`semester`) REFERENCES `semester` (`id`);

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `student_ibfk_1` FOREIGN KEY (`semester_id`) REFERENCES `semester` (`id`),
  ADD CONSTRAINT `student_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `session` (`id`);

--
-- Constraints for table `undergraduate`
--
ALTER TABLE `undergraduate`
  ADD CONSTRAINT `undergraduate_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `semester` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
