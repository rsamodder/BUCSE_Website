<!-- <div class="container">
    <div class="container">
        <div class="samepost clear">
            <h2><a href="">achivement</a></h2>
            <h4>April 10, 2016, 12:30 PM, By <a href="#">Delowar</a></h4>
            <a href="#"><img src="img/bu.png" alt="post image" /></a>
            <p>
                Some text will be go here. Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be
                go here. Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.Some text will be go here.
            </p>
        </div>
    </div>
</div> -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.2.0/css/fontawesome.min.css" />
</head>

<body bg-light>
    <main class="m-5 bg-light border border-2">
        <div class="bg-light float-none m-2">
            <p class="fs-3 m-4 border-bottom border-warning">Title</p>

            <div class="float-left w-25 bg-light h-50">
                <img src="img/icpc20.jpg" alt="post image" />
            </div>
            <div class="float-right w-75 p-2">
                <p class="pd-2">
                    Deadline: 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM Deadline: 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM Deadline: 17-Oct-2022
                    12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM Deadline: 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM
                </p>
            </div>
            <br>
            <div class="bg-light  m-2">
                <p class="fs-3 m-4 border-bottom border-warning">Title</p>

                <div class="float-left w-25 bg-light h-50">
                    <img src="img/icpc20.jpg" alt="post image" />
                </div>
                <div class="float-right w-75 p-2">
                    <p class="pd-2">
                        Deadline: 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM Deadline: 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM Deadline: 17-Oct-2022
                        12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM Deadline: 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 P/p> Criterea Unit-C 17-Oct-2022 12:00 PM to 27-Oct-2022 11:59 PM
                    </p>
                </div>
            </div>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
</body>

</html>
<!-- add critea -->