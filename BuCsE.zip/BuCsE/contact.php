

  <!-- <style>
    body{
        font-family: 'Times New Roman', Times, serif';
    }
    .heading{
        text-align: center;
        font-size: 40px;
    }
    .container{
        background-color: beige;
        box-shadow: 2px 2px 5px 5px #a6a6a6;
    }
    .btn-info{
        width: 50%;
        letter-spacing: 2px;
        background: transparent;
        transition: all 0.5s ease-in-out;
    }
    .btn-info:hover{
        transform: scale(1.05s);
        color: aliceblue;
    }
    
  </style> -->

  <?php include 'header.php';?>

    <!-- #A2BD3C -->

    <div class="container pt-4">
        <h2 class="heading" style="text-align: center;
        font-size: 40px; font-family: 'Times New Roman', Times, serif';">Contact Us</h2>
        <hr class="mb-4">

        <br>
        <div class="row">

            <div class="col-md-6">
                <form>
                <!--<label>Name: </label>--><input type="Text" name="Text" required="" placeholder="Please enter your Name here" class="form-control">
                <br>
                <!--<label>Name: </label>--><input type="Email" name="Email" required="" placeholder="Please enter your Email here" class="form-control">
                <br>
                <!--<label>Message: </label>--><textarea rows="6" placeholder="Your Message..." required="" class="form-control"></textarea>

                <br>
                <center>
                <button class="btn btn-warning">Submit</button>
                </center>

                <br>
                </form>
            </div>

            <div class="col-md-1"></div>
    
            <div class="col-md-5 col-lg-4 col-xl-3 mx-auto mt-3">
                <div class="map-area">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14727.848078333385!2d90.36132965!3d22.65520465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755348ec0558363%3A0x71825eb40c8459a6!2sUniversity%20of%20Barishal!5e0!3m2!1sen!2sbd!4v1668581256908!5m2!1sen!2sbd" height= 100% class="img-fluid" style="border: 5px; border-color: black;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <br>
            </div>

            
    
        </div>
    </div>

    <?php include 'footer.php';?>