<?php 
$query = "SELECT * FROM notice WHERE id=$id";

$pdf=$db->select($query);
if($pdf){
    
    while($result=$pdf->fetch_assoc()){
    $filepath = "pdf/".$file_name;;

    if (file_exists($filepath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($filepath));
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize("pdf/".$file_name));
        readfile("pdf/".$file_name);

        // Now update downloads count
        $newCount = $file['downloads'] + 1;
        $updateQuery = "UPDATE notice SET downloads=$newCount WHERE id=$id";
        mysqli_query($conn, $updateQuery);
        exit;
    }

    }}