<?php
$conn=mysqli_connect("localhost","root","","BU_CSE") or die("connection failed!");
?>
