<?php include 'header.php';?>
    

<main>
    <h1 class="text-warning text-uppercase text-center">Faculty</h1><hr></hr>
    <div class="row text-center m-2 d-flex justify-content-around">
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/erfansir.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Md Irfan</h5>
                  <p class="card-text">Assistant Professor & Chairman<br>
                    Cell :01799598455.</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">irfan.bucse@gmail.com</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/monjursir.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Dr. Md Manjur Ahmed</h5>
                  <p class="card-text">Assistant Professor<br>
                    01851924944</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">manjur_39@yahoo.com</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/rahatsir.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Rahat Hossain Faisal</h5>
                  <p class="card-text">Assistant Professor<br>
                    8801733977761</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">rhfaisal@gmail.com;</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/shamssir.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Md. Samsuddoha</h5>
                  <p class="card-text">Assistant Professor
                    <br>01737349075</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">sams.csebu@gmail.com</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/rashidsir.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Md. Rashid Al Asif</h5>
                  <p class="card-text"> 	
                    Lecturer
                    <br>
                    Cell :01734528367</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">rashid.al.asif@gmail.com</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/mostafijsir.png" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Md. Mustafijur Rahman</h5>
                  <p class="card-text">Assistant Professor<br>
                    +8801739097182</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">mostafij.csebu@gmail.com</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/mahboobsir.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Md Mahbub E Noor</h5>
                  <p class="card-text">Lecturer

                    <br>+8801734094560</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">mahbub0601001@gmail.com</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/taniamadam.png" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Tania Islam</h5>
                  <p class="card-text"> 	

                    Lecturer
                    
                    <br>>01059505136</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">tania.bd.09@gmail.com</a>
                </div>
              </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/sohelymadam.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Sohely Jahan</h5>
                  <p class="card-text"> 	

                    Lecturer
                    
                    <br>01317419066</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">sohely.cse@gmail.com</a>
                </div>
              </div>
        </div>
    </div>
   
</main>
<?php include 'footer.php';?>