-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2022 at 04:29 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bu_cse`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_research`
--

CREATE TABLE `tbl_research` (
  `id` int(11) NOT NULL,
  `body` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_research`
--

INSERT INTO `tbl_research` (`id`, `body`, `status`) VALUES
(20, '<p><span>Sheikh Azizul Hakim, Bishal Basak Papan, Md. Saidur Rahman,&nbsp;</span><span>New results on pairwise compatibility graphs</span><span>,&nbsp;</span><em>Information Processing Letters, 2022.&nbsp;<a href=\"https://doi.org/10.1016/j.ipl.2022.106284\">[paper link]</a></em></p>', 1),
(21, '<p><span>Mohammad Mamun Elahi, Md. Mahbubur Rahman, Mohammad Mahfuzul Islam,&nbsp;</span><span>An efficient authentication scheme for secured service provisioning in edge-enabled vehicular cloud networks towards sustainable smart cities</span><span>,&nbsp;</span><em>Sustainable Cities and Society, 76, 2022.&nbsp;<a href=\"https://www.sciencedirect.com/science/article/abs/pii/S2210670721006570?via%3Dihub\">[paper link]</a></em></p>', 1),
(24, '<p><span>Mohammad Mamun Elahi, Md. Mahbubur Rahman, Mohammad Mahfuzul Islam,&nbsp;</span><span>An efficient authentication scheme for secured service provisioning in edge-enabled vehicular cloud networks towards sustainable smart cities</span><span>,&nbsp;</span><em>Sustainable Cities and Society, 76, 2022.&nbsp;[paper link]</em></p>', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_research`
--
ALTER TABLE `tbl_research`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_research`
--
ALTER TABLE `tbl_research`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
