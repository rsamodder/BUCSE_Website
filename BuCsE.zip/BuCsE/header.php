<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <link rel="stylesheet" href="css2/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/all.css">
    <link rel="stylesheet" href="css/fontawesome.css">

    <style>
        #nav li a:hover{
            background-color: rgba(65, 63, 63, 0.61);  
           
        }
        <style>
        .swiper-slide {
            text-align: center;
            font-size: 18px;
            background: #fff;
            /* Center slide text vertically */
            /* display: -webkit-box;
            display: -ms-flexbox;
            display: -webkit-flex;
            display: flex;
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            -webkit-justify-content: center;
            justify-content: center;
            -webkit-box-align: center;
            -ms-flex-align: center;
            -webkit-align-items: center; 
             align-items: center;*/
        }
        
        .swiper-slide img {
            display: block;
            /* width: 100%;
            height: 100%; */
            object-fit: cover;
        }
        
        .card_slider {
            padding: 25px 0px;
        }
    </style>
    </style>
    <title>BU CSE</title>
</head>
<body>
<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">  
    <!-- <header> -->
     <!-- #A2BD3C    -->
     <div class="d-flex position-absolute end-0 m-1">
        <a href='login.php'class="m-1 p-1 text-decoration-none btn" style="background-color:#A2BD3C;">Sign in</a>
        <a href="registration.php"class="m-1 p-1 text-decoration-none btn" style="background-color:#A2BD3C;">Sign Up</a> 
    </div>
        <div class="top-header d-lg-flex d-sm-block">
       
            <img src="image/Barishal_University_logo.svg.png" alt="image" height="70px" weight="70px">
        <div>
           
                <div class="fw-bold fs-4" style="color: #080C32; margin:5px; font-family: 'Times New Roman', Times, serif;">Department of Computer Science and Engineering</div>
                <div class="fw-bold fs-5" style="color: #080C32; margin:5px; font-family: 'Times New Roman', Times, serif;">University of Barishal</div> 
            
        </div>
        
    </div>
        <nav class="navbar sticky-top navbar-expand-lg p-2" style="background-color:#080C32; border-bottom:5px solid yellowgreen;">
            <div class='position-absolute d-flex end-0 top-0'>
                <form action="#" class="position-relative mt-2">
                <input id="abc" class='border-0 display-block w-100' type="text" placeholder="Type to search" style="border-radius: 35px;">
                <button class="bg-white rounded-circle position-absolute top-0 end-0 border-0"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>

                <a href="#" class="text-white"><i class="fa-brands fa-facebook fa-2x p-1 m-1"></i></a>
                <a href="#" class="text-white"><i class="fa-brands fa-google-plus-g fa-2x p-1 m-1"></i></a>
                <a href="#" class="text-white"><i class="fa-solid fa-location-dot fa-2x p-1 m-1"></i></a>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon mr-auto bg-white"></span></button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul id="nav" class="navbar-nav m-auto">
            <li class="nav-item active"><a class='nav-link text-white' href="index.php">Home</a></li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">About</a>
                <ul class="dropdown-menu dropdown-menu-dark" style="background-color: #080C32;">
                    <li><a class="dropdown-item text-white" href="about.php">About Bu CSE</a></li>
                    <li><a class="dropdown-item text-white" href="achievement.php">Achievements</a></li>
                    <li><a class="dropdown-item text-white" href="#">facilities</a></li>
                    <li><a class="dropdown-item text-white" href="contact.php">Contact</a></li>

               </ul>
            
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">Academic</a>
                <ul class="dropdown-menu  dropdown-submenu dropdown-menu-dark" style="background-color: #080C32;">
                    <li><a class="dropdown-item text-white" href="admission.php">Admission</a></li>
                    <li class="nav-item dropdown dropend">
                        <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">Curriculum</a>
                        <ul class="dropdown-menu  dropdown-submenu dropdown-menu-dark" style="background-color: #080C32;">
                            <li><a class="dropdown-item text-white" href="undergraduate.php">Undergraduate</a></li>
                            <li><a class="dropdown-item text-white" href="#">Graduate</a></li>  
                       </ul>
                    </li>

                    
               </ul>
            </li>
            <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Announcement</a>
            <ul class="dropdown-menu dropdown-menu-dark" style="background-color: #080C32;">
                <li><a class="dropdown-item text-white" href="notice.php">Notice Board</a></li>
                <li><a class="dropdown-item text-white" href="#">News and events</a></li>
              </ul>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-white" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                 people
                </a>
                <ul class="dropdown-menu dropdown-menu-dark" style="background-color: #080C32;">
                  <li><a class="dropdown-item text-white" href="faculty.php">faculty</a></li>
                  <li><a class="dropdown-item text-white" href="stuffs.php">stuffs</a></li>
                </ul>
              </li>

              <li class="nav-item"><a class='nav-link text-white' href="#">Research</a></li>
              <li class="nav-item"><a class='nav-link text-white' href="#">Alumni</a></li>
            </ul>
   </div>
      
    </nav>