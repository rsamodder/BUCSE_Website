<?php include 'header.php';?>

<main>

    <h1 class="text-warning text-uppercase text-center">Stuffs</h1><hr></hr>
    <div class="row text-center m-2 d-flex justify-content-around">
        <div class="col-lg-3 col-md-6 col-sm-12 mb-2 d-flex justify-content-around">
            <div class="card shadow-lg border-start-0 border-0" style="width: 15rem;">
                <img src="image/yeasmin.jpg" class="card-img-top" alt="img" height="200px">
                <div class="card-body">
                  <h5 class="card-title">Farjana Yesmin</h5>
                  <p class="card-text">Administrative Officer<br>
                    Cell :01799598455.</p>
                  <a href="#" class="btn" style="background-color: #A2BD3C;">yesminfarjana61@gmail.com</a>
                </div>
              </div>
        </div>
<!-- JavaScript Bundle with Popper -->
<?php include 'footer.php';?>