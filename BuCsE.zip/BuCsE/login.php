<?php include 'header.php';?>

<main>
    
    <form class="m-auto mt-3 p-3 pb-5 border-start-5 w-25 rounded shadow" action="" method=''>
        <div class="title d-flex justify-content-center"><i class="fa-2x fa fa-user text-center p-2 rounded-circle " style="color: #A2BD3C;background-color: silver;"></i></div><h1 class="text-center" style="color: #A2BD3C">Welcome</h1>
          <div><i class="fa-2x fa fa-envelope email" style="color: #A2BD3C;"></i><input type="email" required placeholder="Email" class="form-control" name='email'></div> 
        <div class='mt-3 '><i class="fa-2x fa fa-lock lock" style="color: #A2BD3C;"></i><input type="Password" required placeholder="password" class="form-control" name='password'></div>
        <div class='mt-3 mb-2'> <input type="submit" value="Login" required></div>
        <div class="link"><span>Don't have an account?</span><a href="Registration.html">Register here</a></div> 
      </form>
</main>
<script src="js/bootstrap.bundle.min.js"></script>

    </body>
    </html>
