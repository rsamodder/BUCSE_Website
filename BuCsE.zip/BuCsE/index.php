<?php include "include/header.php"; ?>
    <!-- slider -->
    <div id="carouselExampleCaptions" class="carousel carousel-dark slide m-4" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="3" aria-label="Slide 4"></button>

        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="img/bu2.jpg" class="d-block w-100" alt="Bu">
                <div class="carousel-caption d-none d-md-block">
                    <h5>First slide label</h5>
                    <p>Welcome to Our CSE Family</p>
                </div>
            </div>
            <!-- <div class="carousel-item">
                <img src="img/11bu.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Second slide label</h5>
                    <p>Some representative placeholder content for the second slide.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/icpc22019.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Second slide label</h5>
                    <p>Some representative placeholder content for the second slide.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="img/4icpc2019.jpg" class="d-block w-100" alt="...">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Third slide label</h5>
                    <p>Some representative placeholder content for the third slide.</p>
                </div>
            </div> -->
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" ></span>
         
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
          <span class="carousel-control-next-icon" ></span>
         
        </button>
    </div>

    <!-- end -->
    
<?php include "include/body.php"; ?>

        <div class="float-none m-5">

            <section class="">
                <div class="bg-light pt-">
                    <p class="border-bottom border-dark fs-3 ">Achievement</p>
                </div>
                <!-- Additional required wrapper -->

                <div class="swiper card_slider">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide m-2">
                            <div class="img_box">
                                <img class="m-2 border-2 border-success" src="img/bu1.png" alt="" />
                            </div>
                            <a class="link-dark" href=""><strong>Buians secured First Place in BUET CSE Fest 2022</strong></a>
                            </a>
                        </div>
                        <div class="swiper-slide m-2">
                            <div class="img_box">
                                <img class="m-2 border-2 border-success" src="img/icpc20.jpg" alt="" />
                            </div>
                            <a class="link-dark" href=""> <strong>Buians secured First Place in BUET CSE Fest 2022</strong></a>
                        </div>
                        <div class="swiper-slide m-2">
                            <div class="img_box">
                                <img class="m-2 border-2 border-success" src="" alt="" />
                            </div>
                            <a class="link-dark" href=""> <strong>Buians secured First Place in BUET CSE Fest 2022</strong></a>
                        </div>
                        <div class="swiper-slide m-2">
                            <div class="m-2 border-2 border-success" class="img_box">
                                <img src="" alt="" />
                            </div>
                            <a class="link-dark" href=""> <strong>Buians secured First Place in BUET CSE Fest 2022</strong></a>
                        </div>
                        <div class="swiper-slide m-2">
                            <div class="img_box">
                                <img class="m-2 border-2 border-success" src="img/icpcg.jpg" alt="" />
                            </div>
                            <a class="link-dark" href=""> <strong>Buians secured First Place in BUET CSE Fest 2022</strong></a>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_box">
                                <img class="m-2 border-2 border-success" src="img/icpc22019.jpg" alt="" />
                            </div>
                            <a class="link-dark" href=""> <strong>Buians secured First Place in BUET CSE Fest 2022</strong></a>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_box">
                                <img class="m-2 border-2 border-success" src="img/gift1.jpg" alt="" />
                                <a class="link-dark" href=""> <strong>Buians secured First Place in BUET CSE Fest 2022</strong></a>

                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="img_box">
                                <img class="m-2 border-2 border-success" src="img/icpc61th2.jpg" alt="" />
                                <strong>Buians secured First Place in BUET CSE Fest 2022</strong>

                            </div>
                        </div>
                        <div class="swiper-slide">Slide 9</div>
                    </div>
                    <!-- If we need navigation buttons -->
                    <div class="swiper-button-prev"></div>

                    <div class="swiper-button-next"></div>

                    <div class="swiper-button-"></div>
                    <!-- If we need pagination-->

                    <div class="swiper-pagination"></div>

                    <!-- If we need scrollbar -->

                    <div class="swiper-scrollbar"></div>
                </div>
            </section>
        </div>
    </div>
 
    
<!-- add achieve -->
<?php include "include/footer.php"; ?>