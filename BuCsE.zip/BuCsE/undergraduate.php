<?php include 'header.php';?>

<main>
    <div class="container mt-5">
    <h1 class="text-warning text-uppercase text-center">1st semester</h1><hr></hr>
    <table class="table table-bordered text-center table-hover table-striped">
        <tr style="background-color: #A2BD3C;">
            <th>Serial</th>
            <th>Course Name</th>
            <th>Course code</th>
          </tr>
          <tr>
            <td>1</td>
            <td>Design and Analysis of Algorithm</td>
            <td>CSE-2201</td>
          </tr>
          <tr>
            <td>2</td>
            <td>CSE-2202: Design and Analysis of Algorithm Lab</td>
            <td>Md. Erfan</td>
          </tr>
          <tr>
            <td>3</td>
            <td>CSE-2203: Computer Architecture and Organization</td>
            <td>Dr. Md. Manjur Ahmed</td>
          </tr>
          <tr>
            <td>4</td>
            <td>CSE-2205: Data Communication</td>
            <td>Sohely Jahan</td>
          </tr>
          <tr>
            <td>5</td>
            <td>CSE-2207: Operating System</td>
            <td>Md. Rashid Al Asif</td>
          </tr>
          <tr>
            <td>6</td>
            <td>CSE-2208: Operating System Lab</td>
            <td>Md. Rashid Al Asif</td>
          </tr>
          <tr>
            <td>7</td>
            <td>CSE-2210: Web Engineering Lab</td>
            <td>Md. Samsuddoha</td>
          </tr>
          <tr>
            <td>8</td>
            <td>MATH-2211: Vector, Fourier Analysis and Laplace Transforms</td>
            <td>TBA</td>
          </tr>
            </table></div>
</main>
<?php include 'footer.php';?>