<?php include 'header.php';?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Research</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>

  <body>

    <br>

    <!-- #A2BD3C -->

    <div class="container my-2 pt-2 shadow" style="background-color: rgb(238, 247, 250);">
        <h2 class="heading" style="text-align: center; font-size: 35px; font-family: 'Times New Roman', Times, serif'; ">Research and Publication</h2>
        <hr class="mb-4">


        
        <h4><span class="border-bottom border-3 border-warning">Ongoing Research:</span></h4>
        <table class="table table-responsive table-striped">
            <tbody>
            <?php
					$query="select * from tbl_research where status ='0' order by id desc";
					$msg= $db->select($query);
					if($msg){
						$i=0;
						while($result=$msg->fetch_assoc())
						{
							$i++;
						
					
						?>
                <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $result['body'];?></td>
                </tr>
                <?php
                  
                        }}
                  ?>
            </tbody>
          </table>  
          
          
          <br>
        
        <h4><span class="border-bottom border-3 border-warning">Completed Research:</span></h4>
        <table class="table table-responsive table-striped">
            <tbody>
            <?php
					$query="select * from tbl_research where status ='1' order by id desc";
					$msg= $db->select($query);
					if($msg){
						$i=0;
						while($result=$msg->fetch_assoc())
						{
							$i++;
						
					
						?>
                <tr>
                    <td><?php echo $i;?></td>
                    <td><?php echo $result['body'];?></td>
                </tr>
                <?php
                  
                }}
          ?>
            </tbody>
          </table> 
          <br>
    </div>

  </body>
</html>

<?php include 'footer.php';?>