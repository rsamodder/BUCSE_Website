

    <!-- body -->
    <div class="m-4">
        <div class="mt-4 pd-3 ">
            <div class="float-left w-50 bg-light">
                <p class="fs-3 m-4 border-bottom" style="border-bottom:4px solid #A2BD3C ;">Notice Board</p>
                <p>
                    Documentation and examples for opting images into responsive behavior (so they never become larger than their parent elements) and add lightweight styles to them—all via classes.
                </p>

                <a href="notice.php" role="button" class="btn btn-dark">
            ...Read More</a
          >
        </div>
        <div class="float-right w-50 bg-light">
          <p class="fs-3 m-4 border-bottom " style="border-bottom:4px solid #A2BD3C  ;">Admission</p>

          <!-- #A2BD3C -->
          <p> Documentation and examples for opting images into responsive
            behavior (so they never become larger than their parent elements)
            and add lightweight styles to them—all via classes.
          </p>
          <a href="admission.php" role="button" class="btn btn-dark"
            >...Read More
          </a>
            </div>
        </div>
        <div class="mb-4"><div>
        
        <!-- body -->

        <!-- <h2>Read More Read Less Button</h2>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus imperdiet, nulla et dictum interdum, nisi lorem egestas vitae scel<span id="dots">...</span><span id="more">erisque enim ligula venenatis dolor. Maecenas nisl est, ultrices nec congue eget, auctor vitae massa. Fusce luctus vestibulum augue ut aliquet. Nunc sagittis dictum nisi, sed ullamcorper ipsum dignissim ac. In at libero sed nunc venenatis imperdiet sed ornare turpis. Donec vitae dui eget tellus gravida venenatis. Integer fringilla congue eros non fermentum. Sed dapibus pulvinar nibh tempor porta.</span></p>
<button onclick="myFunction()" id="myBtn">Read more</button> -->