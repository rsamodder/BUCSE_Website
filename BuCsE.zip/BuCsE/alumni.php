<?php include 'header.php';?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Alumni</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  </head>

  <body>



<div class="container my-1 pt-1 border-bottom border-5 border-warning">
    <!-- #A2BD3C -->
    <h2  style="text-align: center; font-size: 35px; font-family: 'Times New Roman', Times, serif'; ">
        Alumni
    </h2>
</div>


    <div class="container border border-warning my-4 pt-4 shadow" style="background-color: rgb(238, 247, 250);">
        <p style='text-align: justify;'>The Department of Computer Science and Engineering has been a symbol of progress from the earliest stages of its conception. Only the brightest of individuals from all over the country congregated under a single notion – to achieve greatness and revolutionize the field of Computer Science and Engineering with their ingenuity and talent. The tradition has been passed down to later generations who also followed in the footsteps of their predecessors to achieve excellence through their effort and performance.
            <br><br>

            More than a thousand individuals have graduated from the department and are pursuing their dynamic careers worldwide. The spectrum of career choices of our alumni stretches from Software Engineering in the most reputable companies worldwide to Faculty positions in the most respected universities and from IT specialists in multi-national companies to researchers in the highest ranking universities. Their excellence and conviction to their career of choice is prevalent in their performance and achievements.
            <br><br>
            
            All the alumni are considered to be a member of the Computer Science and Engineering family. They maintain close ties among themselves through regular extravaganzas arranged by the department or the Alumni Association. These spectacles transform in to an assortment of reminiscence and knowledge sharing. The department is proud of each and every one of its alumni for upholding the department’s name in local and international frontiers.
            
            <br><br>
            Click here to visit the people for Computer Science and Engineering, University of Barishal.</p>
    </div>

    <div class="container border border-warning my-4 pt-4 shadow" style="background-color: rgb(238, 247, 250);">
        <table class="table table-responsive table-hover text-center">
            <tbody>
                <tr>
                    <td href="alumniList.html">2013-14</td>
                </tr>
                <tr>
                    <td href="alumniList.html">2014-15</td>
                </tr>
                <tr>
                    <td href="alumniList.html">2015-16</td>
                </tr>
            </tbody>
        </table> 
        <br>
    </div>

  </body>
</html>

<?php include 'footer.php';?>