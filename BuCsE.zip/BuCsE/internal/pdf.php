<?php include "header.php";?>
<?php

$id=$_GET['id'];
$s1=$_SESSION['s_id'];

$s2=$_SESSION['session'];

$sql="SELECT * FROM result where course='$id' and semester='$s1' and session='$s2'";
$result=$db->select($sql);
                $row=mysqli_fetch_assoc($result);
                if($row){
    ?>
                    <td><a href="../admin/<?php echo $row['materials']; ?>" >View</a></td>
                    <td><a href="../admin/<?php echo $result1['materials']; ?>" download>Download </a></td>
                </tr></table>
    
            
                
                <?php}?>

 
               