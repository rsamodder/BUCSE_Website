<?php include "header.php";?>
 <nav class="navbar sticky-top navbar-expand-lg p-4" style="background-color:#080C32; border-bottom:5px solid yellowgreen;">
 <div class="position-absolute end-0 m-1 p-1">
        <a href='logout.php'class="m-1 p-1 text-decoration-none btn bg-light">log Out</a>
    </div></nav> 
    <h2 style="text-align:center; color:grren;"> Welcome to Student Corner</h2>

<?php
$email=$_SESSION['email'];
$sql="SELECT * from student where email='$email'";
$result=$db->select($sql);
$row=mysqli_fetch_assoc($result);?>
<div class='position-absolute end-0 m-3'><a style="padding:5px;text-decoration:none; color:white; background-color:green;" href="update.php?editId=<?php echo $row['id'];?>"><i class="fa-solid fa-pen"></i>My profile</a></div>
<?php
$_SESSION['s_id']=$row['semester_id'];
$_SESSION['session']=$row['session_id'];

$s_id=$row['semester_id'];
$session=$row['session_id'];
$sql1="SELECT * FROM undergraduate where s_id='$s_id'";
$result1=$db->select($sql1);
echo '<h2>All courses</h2>';
if($result1){
    while($row1=mysqli_fetch_assoc($result1)){
        $_SESSION['id']=$row1['course_id'];
    ?>
    <div class='m-2'><a href="pdf.php?id=<?php echo $row1['course_id'];?>"><?php echo $row1['title']; ?></a></div>
    <?php } } ?>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>