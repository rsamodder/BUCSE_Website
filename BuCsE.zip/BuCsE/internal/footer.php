<!-- footer -->
<footer class="text-white pt-1 pb-1" style="background-color: #080C32;">
    <div class="container text-center text-md-left ">
        <div class="row text-center text-md-left">
            <div class="col-md-6 col-lg-4 col-xl-3 mx-auto mt-1">
                <img src="image/Marlborough2.png" alt="image" class="img-fluid" height="200px" >
            </div>


            <div class="col-md-6 col-lg-8 col-xl-9 mx-auto">
                <h5 class="" style="font-size: 22px; font-weight: bold; font-family:'Times New Roman', Times, serif;" >Contact Us</h5>
                <hr class="mb-4">
                <p style="font-size: 14px;">
                    <i class="fas fa-map-marker"></i> &nbsp; Kornokathi, Barishal-8254, Bangladesh 
                </p>
                <p style="font-size: 14px;">
                    <i class="fas fa-phone"></i> &nbsp;<b style="font-size: 15px;">Phone :</b> &nbsp; 0431-2177771-77
                </p>
                <p style="font-size: 14px;">
                    <i class="fas fa-envelope"></i> &nbsp;<b style="font-size: 15px;">Email :</b> &nbsp; registrar@bu.ac.bd

                </p>
            </div>
        </div>

        <hr class="mb-1">

        <div class="row align-items-center h-50">
            <div class="col-md-7 col-lg-8">
            <?php
			$sql="SELECT * FROM tbl_cpy";
			
			$result=$db->select($sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
				?>
                <p><?php echo $row['note'];?></p><?php } } ?>
            </div>
        
            <div class="col-md-5 col-lg-4">
                <div class="text-center text-md-right">
                    <ul class="list-unstyled list-inline">
                        <li class="list-inline-item">
                            <a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;"><i class="fab fa-facebook"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;"><i class="fab fa-google-plus"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;"><i class="fab fa-youtube"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>

    </div>
</footer>
<!-- JavaScript Bundle with Popper -->

<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script> -->


<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script type="text/javascript">
        var swiper = new Swiper(".card_slider", {
            slidesPerView: 3,
            spaceBetween: 40,
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
                768: {
                    slidesPerView: 3,
                },
                1200: {
                    slidesPerView: 4,
                },
            },
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="js/bootstrap.min.js" integrity="sha384-+sLIOodYLS7CIrQpBjl+C7nPvqq+FbNUBDunl/OZv93DB7Ln/533i8e/mZXLi/P+" crossorigin="anonymous"></script>
    <script src="js/bootstrap.bundle.min.js"></script>

    </body>
    </html>