
<?php include "header.php";?>
<?php
if($_SERVER['REQUEST_METHOD']=="POST"){
    $id=$_GET['editId'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    $email=$_POST['email'];
    $file=$_FILES['photo']['name'];

if($file){

$sql="UPDATE student SET phone='{$phone}',details='{$address}',email='{$email}',photo='{$file}' WHERE id='$id'";
$result=$db->update($sql);
header("Location: materials.php");
}
else{
    $sql="UPDATE student SET phone='{$phone}',details='{$address}',email='{$email}' WHERE id='$id'";
    $result=$db->update($sql);
    header("Location: materials.php");

}
}
?>
<div class="block">    

                 <form action="" method="POST" enctype="multipart/form-data">
                    <table class="form"  style="padding:45px 25px 25px 25px;background-color:whitesmoke;">
                    <tr><td style="text-align:center; color:orange; font-size:20px;border-left:2px solid orange;">Update profile<td><tr>
                    <?php 
                $id=$_GET['editId'];
                $sql="SELECT * FROM student where id='$id'";
                $result=$db->select($sql);
                $row=mysqli_fetch_assoc($result);
                if($row){
                    
            ?>
            <tr>
                            <td>
                               
                                <label>Name</label>
                            </td>
                            <td>
                                <input type="text" readonly required name='name' value="<?php echo $row['name']; ?>" class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                               
                               <label>Roll</label>
                           </td>
                           <td>
                               <input type="text" readonly required name='roll'  value="<?php echo $row['roll']; ?>" class="medium" />
                           </td>
                       </tr>
                       <tr>
   
                            <td>
                               
                               <label>Reg.</label>
                           </td>
                           <td>
                               <input type="text" readonly required name='reg.'  value="<?php echo $row['reg.']; ?>" class="medium" />
                           </td>
                       </tr>
                       <tr>
                           <td>
                               
                                <label>email</label>
                            </td>
                            <td>
                                <input type="email" required name='email'  value="<?php echo $row['email']; ?>" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                               
                                <label>Phone</label>
                            </td>
                            <td>
                                <input type="text" required name='phone'  value="<?php echo $row['phone']; ?>" class="medium" />
                            </td>
                        </tr>
                        
                        <tr>
                            <td>
                               
                                <label>Details</label>
                            </td>
                            <td>
                                <input type="text" name='address'  value="<?php echo $row['details']; ?>" class="medium" />
                            </td>
                        </tr>
                     
                        <tr>
                            <td>
                               
                                <label>photo</label>
                            </td>
                            <td>
                                <input type="file" name='photo' class="medium" />
                                
                            </td>
                            
                        </tr>
                        
                        <tr>
                            <td>
                               
                                <label>session</label>
                            </td>
                            <td>
                            <input type="text" readonly step="any" name='session'  value="<?php echo $row['session_id']; ?>"/>
                            </td>
                        </tr>
                       
                        <tr>
                            <td>
                               
                                <label>Semester</label>
                            </td>
                            <td>
                            <input type="text"  readonly name='semester'  value="<?php echo $row['semester_id']; ?>"/>
                            </td>
                        </tr>

						<tr>
                            <td></td>
                            <td>
                                <input type="submit" name="submit" style="background-color:green;color:white;padding:5px;border-radius:3px;border-color:none;font-size:15px;" Value="update" />
                            </td>
                        </tr>
                       <?php } ?>
                    </table>
                    </form>
                    <div class='position-absolute top-50 start-50 translate-middle'><img src='../image/rima.jpg' width='150px' height='150px' alt='img'></div>
                </div>
</body>
</html>