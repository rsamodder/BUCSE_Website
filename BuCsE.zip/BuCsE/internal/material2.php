
<?php
session_start();
if(!isset($_SESSION['email'])){
   header('Location:../login.php');
}

if($_SESSION['role']=='0'){
    header('Location:materials.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />

    <link rel="stylesheet" href="../css2/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="../css/all.css">
    <link rel="stylesheet" href="../css/fontawesome.css">

    <style>
    </style>
    <title>faculty</title>
</head>
<body>
    
<nav class="navbar sticky-top navbar-expand-lg p-4" style="background-color:#080C32; border-bottom:5px solid yellowgreen;">
<div class="position-absolute end-0 m-1 p-1">
        <a href='logout.php'class="m-1 p-1 text-decoration-none btn bg-light">log Out</a>
    </div></nav>
    <h2 style="text-align:center; color:grren;"> Welcome to teacher Corner</h2>
    <div class='position-absolute top-50 start-50 translate-middle'><a class='btn btn-secondary' href="../admin/login.php">Go to Admin panel</a></div>
    <div class='position-absolute top-50 start-50 translate-middle m-5'><a class='btn btn-secondary' href="materials.php">Go to student corner</a></div>
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>