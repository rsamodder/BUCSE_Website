<?php include 'header.php';?>
<div class="container display-flex m-auto">
<h1 class="text-center text-warning">About</h1><hr></hr>
<div class="row text-center m-2 d-flex">
<div class="col-lg-6 col-sm-12 mb-2">
<p style='text-align: justify;'>
The Department of Computer Science and Engineering (CSE) at University of Barishal (also known as Barishal University or BU) is a place where brightest of minds from all over the country assemble for a greater future. 

        The department, popularly known as CSEBU, has been inspiring the best and brightest for more than nine years in fostering the frontiers of Computer Science and Engineering. We consider all members of the community as catalysts of evolution and inspire them to break away from traditional learn and apply mentality to create new knowledge and instigate others to do the same.
        <span id="dots">...</span><span id="more">       
        Our credibility and efficacy of the methods of education is reflected by our alumni who have been performing with excellence in their respective fields; in the top-ranking universities as teachers and researchers and in the top companies all around the world as software engineers and IT specialists. Our students are well equipped to take the challenge to stand out as the leaders of tomorrow. We welcome all in our community who are willing to take the challenge. Welcome to progress. Welcome to CSEBU.<br>

        The Department of Computer Science and Engineering has been one of the pioneering organizations in the education sector of Bangladesh since its inception in 1992. The department is keen on pushing the boundaries of traditional education system and vigilant to face the challenges that the ever-changing field of research brings forth. It is the optimum combination of knowledge generation and application that makes the distinctive feature of the department.<br>
        The department focuses on four major perceptions:<br>
        <span class="fw-bolder mt-2">Excellence in Education:</span> From the very beginning, the department is dedicated to provide the best education in the field of Computer Science and Engineering. Armed with a group of experienced faculty and the brightest of students, the department has made exemplary improvement in this field of education. The reflection of this effort can be found amongst the top researchers, programmers, or IT specialists working in top level universities and companies in Bangladesh and all over the world, who graduated from the department.<br>
        <span class="fw-bolder mt-2">Reputation through Research:</span> The department focuses heavily on the quality and impact of the researches done in the field of Computer Science and Engineering as well as in multidisciplinary researches conducted in the department. The researches have been focused towards responding to local and global real-world crises as well as crossing the frontiers of traditional methods to create new knowledge.<br>
        <span class="fw-bolder mt-2">Steps towards Society:</span> The department is always ready to take the responsibility of taking the necessary steps to deploy ICT in social development. The department is keen to fulfill its social responsibility by taking up projects to automate institutional processes at the university and national levels, educate and train people, especially the young people of the country, through workshops on programming, software design, and other ICT training programs.<br>
        <span class="fw-bolder mt-2">Equality for Everyone:</span> Everyone in the Department of Computer Science and Engineering is treated and considered as equal. People past, gender, financial background, ethnicity, religion are not at all considered in the assessment of their present performance. This place gives everyone the opportunity to make a name for themselves and stand out as a member of the CSEBU family. It creates a new identity for the students, one which will be remembered by their department and respected by all.<br>
        <span class="fw-bolder mt-2">Concoction of Culture:</span>The department opens its doors towards diversity. People from all over the country, from different cultural backgrounds come to the department and become a part of the same culture that is practiced in the department. It’s a place for mutual respect and admiration for everyone. This combination of variety ensures an accessible and tolerant environment in the department. An average of 24.59% women out of all students have already pursued degrees from the department which is a reflection of advancement for women in technology in Bangladesh.<br></span>
        </p>
        
            <button onclick="myFunction()" id="myBtn">Read more</button>
       

        </div>

        <div class="col-lg-6 col-sm-12 mb-2">
                <img src="image/cse.jpeg"  alt="img" height="200px">
               
              </div>
        </div></div>
        </span></p>



<script>
function myFunction() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = "Read more"; 
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = "Read less"; 
    moreText.style.display = "inline";
  }
}
</script>
<script src="js/bootstrap.bundle.min.js"></script>

    </body>
    </html>