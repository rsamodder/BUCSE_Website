<?php include 'header.php';?>
    

<main>
    <form class="m-2 p-2 w-lg-50 m-auto mt-3 w-sm-100">
        <div class="text-uppercase fw-bold" style="color: #A2BD3C; font-size: 25px;">Registration Form</div><hr></hr>
        <div class="d-lg-flex d-block" style="color: #A2BD3C;"> <i class="fa fa-user"></i><input type="text" required placeholder="First Name" class="form-contol ms-2 mb-3">
        <div class="ms-2"><input type="text" required placeholder="Last Name" class="form-contol mb-2"></div> 
    </div>     
          <div style="color: #A2BD3C;"><i class="fa fa-envelope email"></i><input type="email" required placeholder="Email" class="form-contol ms-2 mb-3"></div> 
        <div style="color: #A2BD3C;"><i class="fa fa-lock lock"></i><input type="Password" required placeholder="password" class="form-contol ms-2 mb-3"></div>
        <div style="color: #A2BD3C;"><i class="fa fa-lock lock"></i><input type="Password" required placeholder="confirm password" class="form-contol ms-2 mb-3"></div>
        <div ><input type="radio" required name="a" class="form-contol mb-3"><label>Male</label>
        <input type="radio" required name="a" class="form-contol mb-3"><label>Female</label></div>
        <div class="mb-2">
            <select>
                <option>Select a country</option>
                <option>America</option>
                <option>Bangladesh</option>
                <option>Canada</option>
                <option>Etly</option>
            </select>
        </div>
        <div><input type="checkbox" required class="form-contol mb-2"><label>I agree the terms and condition</label></div>
        <div> <input type="submit" value="Register" required class="form-contol mb-2"></div>
          
      </form>
</main>
<script src="js/bootstrap.bundle.min.js"></script>

    </body>
    </html>