home page er post er moto acivement add  korte pri  blog er 
<!-- add acivement -->