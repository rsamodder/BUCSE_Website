-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2022 at 05:56 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blogwithphp`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cate`
--

CREATE TABLE `tbl_cate` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cate`
--

INSERT INTO `tbl_cate` (`id`, `name`) VALUES
(1, 'Java '),
(2, 'PHP'),
(3, 'HTML'),
(4, 'CSS'),
(6, 'Health care');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

CREATE TABLE `tbl_contact` (
  `id` int(11) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `email` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`id`, `firstname`, `lastname`, `email`, `body`, `date`, `status`) VALUES
(11, 'S', 'Ema', 'sefatanema@gmail.com', 'Hellow', '2022-10-30 10:34:24', 1),
(12, 'S', 'Ema', 's@gmail.com', 'Need Help!', '2022-10-30 10:34:15', 1),
(13, 'Sefatan', 'Ema', 'sefatanema@gmail.com', 'Hellow', '2022-10-30 10:33:53', 0),
(14, 'S', 'Ema', 'ema.cse6.bu@gmail.com', 'Hellow! This is Ema', '2022-10-30 10:33:20', 0),
(15, 'Sefatan', 'Ema', 'ema.cse6.bu@gmail.com', 'hi!', '2022-10-30 10:33:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cpy`
--

CREATE TABLE `tbl_cpy` (
  `id` int(11) NOT NULL,
  `note` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_cpy`
--

INSERT INTO `tbl_cpy` (`id`, `note`) VALUES
(1, 'Sefatan  Sowda Ema');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_page`
--

CREATE TABLE `tbl_page` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `body` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_page`
--

INSERT INTO `tbl_page` (`id`, `name`, `body`) VALUES
(1, 'About Me  ', '<p>Hi, this is sefatan sowda Ema. I am a university 3rd year student&nbsp; and currently doing my BSc. in Computer Science And Engineering&nbsp;at university of barishal. My home district is Barisal.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE `tbl_post` (
  `id` int(11) NOT NULL,
  `categ` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `image` varchar(266) NOT NULL,
  `author` varchar(50) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`id`, `categ`, `title`, `body`, `image`, `author`, `tags`, `date`, `userId`) VALUES
(2, 3, 'Html post title will be go here.', '<p><strong>HTML Stands for</strong>&nbsp;<strong>HyperText Markup Language.</strong>&nbsp;<strong>HTML</strong>&nbsp;is used for<span>&nbsp;creating Web pages.</span></p>\r\n<p><span><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem? Possimus, cum! Est, laboriosam corrupti! &nbsp;Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem?&nbsp;</span></span></p>', 'upload/0844c0f67e.png', '  Ema', 'Html code', '2022-10-29 06:55:10', 0),
(3, 4, 'This is about CSS language. ', '<p>Cascading Style Sheets is a style sheet language used for describing the presentation of a document written in a markup language such as HTML or XML. CSS is a cornerstone technology of the World Wide Web, alongside HTML and JavaScript.It can be used to adjust content size, spacing, color and font or add decorative features, such as animations or split content into columns.</p>\r\n<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem? Possimus, cum! Est, laboriosam corrupti! &nbsp;Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?</p>', 'upload/916d253ae3.png', '   Sefatan Ema', 'CSS', '2022-10-29 07:05:34', 0),
(4, 6, 'This is about Health issues.', '<p><span>Health</span><span>, according to the World&nbsp;</span><span>Health</span><span>&nbsp;Organization, is \"a state of complete physical, mental and social well-being and not merely the absence of disease .</span></p>\r\n<p><span><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem? Possimus, cum! Est, laboriosam corrupti! &nbsp;Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem?&nbsp;</span></span></p>', 'upload/12220a479a.jpg', 'Sefatan Ema', 'Health', '2022-10-29 07:13:58', 0),
(5, 1, 'This is about Java language.', '<p><span><span>Java is a high-level, class-based, object-oriented programming language that is designed to have as few implementation dependencies as possible</span><span>.</span></span></p>\r\n<p><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem? Possimus, cum! Est, laboriosam corrupti! &nbsp;Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem?&nbsp;</span></p>', 'upload/ca3bfb909c.png', '  Author', 'Java code', '2022-10-29 06:58:25', 0),
(6, 2, 'This is about PHP language.', '<p><span>PHP is a general-purpose scripting language geared toward web development. It was originally created by Danish-Canadian programmer Rasmus Lerdorf in 1993. The PHP reference implementation is now produced by The PHP Group.</span></p>\r\n<p><span><span>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore animi molestiae, corrupti molestias ipsa a quidem blanditiis voluptatibus doloremque quibusdam, beatae, ex maxime rem? Possimus, cum! Est, laboriosam corrupti! &nbsp;Lorem ipsum dolor sit amet consectetur, adipisicing elit. Iusto laboriosam assumenda incidunt quo adipisci est laborum ipsa dolorem! Eius, ullam?</span></span></p>', 'upload/99755536a5.png', '   Ema', 'PHP', '2022-10-29 07:20:23', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_slider`
--

CREATE TABLE `tbl_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_slider`
--

INSERT INTO `tbl_slider` (`id`, `title`, `image`) VALUES
(5, '3rd slide title', 'upload/slider/1f49957daa.jpg'),
(6, '2nd slide title', 'upload/slider/93240b57e1.jpg'),
(8, '4rth slide title', 'upload/slider/21d5e3bad6.jpg'),
(10, '4rth slide title', 'upload/slider/aac51b0ae5.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_social`
--

CREATE TABLE `tbl_social` (
  `id` int(11) NOT NULL,
  `Fb` varchar(250) NOT NULL,
  `Ln` varchar(250) NOT NULL,
  `Tw` varchar(250) NOT NULL,
  `Gg` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_social`
--

INSERT INTO `tbl_social` (`id`, `Fb`, `Ln`, `Tw`, `Gg`) VALUES
(1, 'www.facebook.com', 'www.lnkedin.com', 'www.twitter.com', 'www.google.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `details` text NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `email`, `details`, `role`) VALUES
(16, 'Sefatan Sowda Ema', '202cb962ac59075b964b07152d234b70', 'ema.cse6.bu@gmail.com', '', 3),
(17, 'Sefatan Ema', '202cb962ac59075b964b07152d234b70', 'sefatanema@gmail.com', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `title_slogan`
--

CREATE TABLE `title_slogan` (
  `id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `slogan` varchar(250) NOT NULL,
  `inst` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `title_slogan`
--

INSERT INTO `title_slogan` (`id`, `title`, `slogan`, `inst`, `logo`) VALUES
(1, 'Welcome To My PHP Project.', 'Sefatan Sowda Ema', 'University Of Barishal', 'upload/78076277b8.png');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_cate`
--
ALTER TABLE `tbl_cate`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cpy`
--
ALTER TABLE `tbl_cpy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_page`
--
ALTER TABLE `tbl_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_post`
--
ALTER TABLE `tbl_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_social`
--
ALTER TABLE `tbl_social`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `title_slogan`
--
ALTER TABLE `title_slogan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_cate`
--
ALTER TABLE `tbl_cate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_contact`
--
ALTER TABLE `tbl_contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tbl_cpy`
--
ALTER TABLE `tbl_cpy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_page`
--
ALTER TABLE `tbl_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_post`
--
ALTER TABLE `tbl_post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_slider`
--
ALTER TABLE `tbl_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_social`
--
ALTER TABLE `tbl_social`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `title_slogan`
--
ALTER TABLE `title_slogan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
